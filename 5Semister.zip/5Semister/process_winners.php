<?php
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES["file"])) {
    $file = $_FILES["file"]["tmp_name"];

    if (($handle = fopen($file, "r")) !== FALSE) {
        // Prepare new HTML content
        $htmlContent = "<!DOCTYPE html>
        <html lang='en'>
        <head>
            <meta charset='UTF-8'>
            <meta name='viewport' content='width=device-width, initial-scale=1.0'>
            <title>Winners List</title>
            <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css' rel='stylesheet'>
        </head>
        <body>
            <div class='container mt-5'>
                <h2 class='text-center'>Sports Winners</h2>
                <table class='table table-bordered mt-4'>
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>PIN Number</th>
                            <th>Branch</th>
                            <th>Sport</th>
                            <th>Position</th>
                        </tr>
                    </thead>
                    <tbody>";

        // Read each row from the CSV file
        $rowIndex = 0;
        while (($row = fgetcsv($handle, 1000, ",")) !== FALSE) {
            if ($rowIndex == 0) {
                $rowIndex++; // Skip the header row
                continue;
            }

            $name = htmlspecialchars($row[0]);
            $pin = htmlspecialchars($row[1]);
            $branch = htmlspecialchars($row[2]);
            $sport = htmlspecialchars($row[3]);
            $position = htmlspecialchars($row[4]);

            $htmlContent .= "<tr>
                                <td>$name</td>
                                <td>$pin</td>
                                <td>$branch</td>
                                <td>$sport</td>
                                <td>$position</td>
                            </tr>";
        }

        fclose($handle);

        $htmlContent .= "</tbody>
                </table>
            </div>
        </body>
        </html>";

        // Save content to winners.html
        file_put_contents("winners.html", $htmlContent);

        echo "<script>alert('Winners list updated successfully!'); window.location.href='winners.html';</script>";
    } else {
        echo "Error opening file!";
    }
} else {
    echo "Invalid file upload!";
}
?>
